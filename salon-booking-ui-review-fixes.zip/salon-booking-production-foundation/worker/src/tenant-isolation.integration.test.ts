/**
 * Integration tests: two salons, one database, real Worker code path.
 *
 * These run only when TEST_DATABASE_URL points at a Neon TEST branch whose schema
 * has been migrated (worker/migrations/0001–0003). They never run against production.
 *
 *   TEST_DATABASE_URL="postgres://..." npx vitest run worker
 */
import {describe,expect,it,beforeAll} from "vitest";
import worker from "./index";

const DATABASE_URL=process.env.TEST_DATABASE_URL??"";
const ORIGIN="http://localhost:5173";
const runId=Date.now().toString(36)+Math.random().toString(36).slice(2,6);
// Unique per run so rate limits from earlier runs never block these tests.
const CLIENT_IP="test-"+runId;
const env={DATABASE_URL} as unknown as Parameters<typeof worker.fetch>[1];

async function call(method:string,path:string,{token,body}:{token?:string;body?:unknown}={}){
  const headers:Record<string,string>={Origin:ORIGIN,"CF-Connecting-IP":CLIENT_IP};
  if(body!==undefined)headers["Content-Type"]="application/json";
  if(token)headers.Authorization="Bearer "+token;
  const response=await worker.fetch(new Request("https://api.test"+path,{method,headers,body:body===undefined?undefined:JSON.stringify(body)}),env);
  const json=await response.json().catch(()=>({})) as Record<string,any>;
  return {status:response.status,json};
}


async function registerOwner(label:string){
  const res=await call("POST","/auth/register",{body:{
    displayName:`Owner ${label}`,email:`owner-${label}-${runId}@test.invalid`,
    password:"correct horse battery",businessName:`Salon ${label} ${runId}`,city:"Beirut",
  }});
  if(res.status!==201)throw new Error(`register ${label} failed: ${res.status} ${JSON.stringify(res.json)}`);
  return {token:res.json.token as string,businessId:res.json.business.id as string,email:`owner-${label}-${runId}@test.invalid`};
}

const skip=!DATABASE_URL;

describe.skipIf(skip)("tenant isolation (integration)",()=>{
  let a:Awaited<ReturnType<typeof registerOwner>>;
  let b:Awaited<ReturnType<typeof registerOwner>>;
  let serviceOfA:string;

  beforeAll(async()=>{
    a=await registerOwner("a");
    b=await registerOwner("b");
    const created=await call("POST","/provider/services",{token:a.token,body:{name:"Haircut A",category:"Hair",durationMinutes:45,price:30}});
    expect(created.status).toBe(201);
    serviceOfA=created.json.service.id;
  });

  it("owner B's workspace never contains salon A's data",async()=>{
    const boot=await call("GET","/provider/bootstrap",{token:b.token});
    expect(boot.status).toBe(200);
    expect(boot.json.business.id).toBe(b.businessId);
    const ids=(boot.json.services as {id:string}[]).map(s=>s.id);
    expect(ids).not.toContain(serviceOfA);
  });

  it("owner B cannot edit salon A's service",async()=>{
    const res=await call("PATCH","/provider/services/"+serviceOfA,{token:b.token,body:{name:"Hijacked",category:"Hair",durationMinutes:45,price:1}});
    expect(res.status).toBe(404);
    const boot=await call("GET","/provider/bootstrap",{token:a.token});
    const svc=(boot.json.services as {id:string;name:string;price:number}[]).find(s=>s.id===serviceOfA);
    expect(svc?.name).toBe("Haircut A");
    expect(svc?.price).toBe(30);
  });

  it("owner B cannot deactivate salon A's service",async()=>{
    const res=await call("DELETE","/provider/services/"+serviceOfA,{token:b.token});
    expect(res.status).toBe(404);
    const boot=await call("GET","/provider/bootstrap",{token:a.token});
    const svc=(boot.json.services as {id:string;active:boolean}[]).find(s=>s.id===serviceOfA);
    expect(svc?.active).toBe(true);
  });

  it("rejects requests without a valid session",async()=>{
    expect((await call("GET","/provider/bootstrap")).status).toBe(401);
    expect((await call("GET","/provider/bootstrap",{token:"0".repeat(64)})).status).toBe(401);
    expect((await call("POST","/provider/services",{body:{name:"x",durationMinutes:30,price:1}})).status).toBe(401);
  });

  it("logout revokes the session",async()=>{
    const session=await registerOwner("logout");
    expect((await call("GET","/provider/bootstrap",{token:session.token})).status).toBe(200);
    await call("POST","/auth/logout",{token:session.token});
    expect((await call("GET","/provider/bootstrap",{token:session.token})).status).toBe(401);
  });

  it("does not reveal whether an email exists on failed login",async()=>{
    const wrongPassword=await call("POST","/auth/login",{body:{email:a.email,password:"wrong password 123"}});
    const unknownEmail=await call("POST","/auth/login",{body:{email:`nobody-${runId}@test.invalid`,password:"wrong password 123"}});
    expect(wrongPassword.status).toBe(401);
    expect(unknownEmail.status).toBe(401);
    expect(wrongPassword.json.error).toBe(unknownEmail.json.error);
  });

  it("locks sign-in for an email after repeated failed attempts",async()=>{
    const email=`lockout-${runId}@test.invalid`;
    await call("POST","/auth/register",{body:{displayName:"Lock",email,password:"correct horse battery",businessName:"Lock "+runId,city:"Beirut"}});
    let last=0;
    for(let i=0;i<11;i++){last=(await call("POST","/auth/login",{body:{email,password:"wrong password 123"}})).status;}
    expect(last).toBe(429);
  });

  it("rejects duplicate registration",async()=>{
    const res=await call("POST","/auth/register",{body:{displayName:"Dup",email:a.email,password:"correct horse battery",businessName:"Dup",city:"Beirut"}});
    expect(res.status).toBe(409);
  });
});

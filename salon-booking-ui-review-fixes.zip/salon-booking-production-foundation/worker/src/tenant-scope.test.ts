/**
 * Static tenant-isolation guard.
 *
 * Every SQL statement that reads or writes a tenant-owned table must filter on
 * business_id, so one salon can never read or change another salon's data even
 * if an id is guessed. This test fails the build if a new query forgets the filter.
 */
import {readFileSync} from "node:fs";
import {fileURLToPath} from "node:url";
import {describe,expect,it} from "vitest";

const source=readFileSync(fileURLToPath(new URL("./index.ts",import.meta.url)),"utf8");

const TENANT_TABLES=[
  "services","employees","customers","appointments","payments","expenses",
  "client_appointment_requests","customer_consent_events","customer_reminders",
  "commission_entries","payroll_payments",
];

const statements=[...source.matchAll(/sql`([\s\S]*?)`/g)].map(match=>match[1]);
const tenantStatements=statements.filter(text=>TENANT_TABLES.some(table=>text.includes(`private.${table}`)));

describe("tenant scoping of SQL statements",()=>{
  it("finds the tenant-owned queries it is meant to check",()=>{
    expect(tenantStatements.length).toBeGreaterThan(10);
  });

  it("every tenant-owned statement filters on business_id",()=>{
    // Valid patterns: INSERTs take business_id from the authenticated session in VALUES;
    // SELECT/UPDATE/DELETE must constrain business_id in the WHERE/JOIN clause.
    const isScoped=(text:string)=>{
      const flat=text.replace(/\s+/g," ");
      if(/to_regclass\(|information_schema/i.test(flat)) return true; // schema health checks, no tenant rows
      if(/^\s*insert\s+into/i.test(flat)) return flat.includes("${businessId}");
      return /business_id\s*=\s*\$\{businessId\}/.test(flat);
    };
    const unscoped=tenantStatements
      .filter(text=>!isScoped(text))
      .map(text=>text.replace(/\s+/g," ").slice(0,140));
    expect(unscoped,`Unscoped tenant queries:\n${unscoped.join("\n")}`).toEqual([]);
  });
});

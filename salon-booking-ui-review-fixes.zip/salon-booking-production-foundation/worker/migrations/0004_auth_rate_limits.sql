-- Fixed-window rate limits for authentication endpoints (login and registration).
-- Keys are hashed by the Worker, so no raw emails or IP addresses are stored.
create table if not exists private.auth_rate_limits (
  key text primary key,
  window_start timestamptz not null default now(),
  attempts integer not null default 0 check (attempts >= 0)
);
